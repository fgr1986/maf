package memristorModelsUI;

import memristorModels.MemristorModel;

public interface MemristorModelMenu {
	public MemristorModel getMemristor();

	public void setMontecarlo();

	public void setSpaceExploration();
}
